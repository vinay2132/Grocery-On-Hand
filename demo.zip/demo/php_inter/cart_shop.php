<?php 
session_start();
$connect = mysqli_connect("localhost", "root", "", "demo2");

if(isset($_POST["add_to_cart"]))
{
	if(isset($_SESSION["shopping_cart"]))
	{
		$item_array_id = array_column($_SESSION["shopping_cart"], "item_id");
		if(!in_array($_GET["id"], $item_array_id))
		{
			$count = count($_SESSION["shopping_cart"]);
			$item_array = array(
				'item_id'			=>	$_GET["id"],
				'item_name'			=>	$_POST["hidden_name"],
				'item_price'		=>	$_POST["hidden_price"],
				'item_quantity'		=>	$_POST["quantity"]
			);
			$_SESSION["shopping_cart"][$count] = $item_array;
		}
		else
		{
			echo '<script>alert("Item Already Added")</script>';
		}
	}
	else
	{
		$item_array = array(
			'item_id'			=>	$_GET["id"],
			'item_name'			=>	$_POST["hidden_name"],
			'item_price'		=>	$_POST["hidden_price"],
			'item_quantity'		=>	$_POST["quantity"]
		);
		$_SESSION["shopping_cart"][0] = $item_array;
	}
}

if(isset($_GET["action"]))
{
	if($_GET["action"] == "delete")
	{
		foreach($_SESSION["shopping_cart"] as $keys => $values)
		{
			if($values["item_id"] == $_GET["id"])
			{
				unset($_SESSION["shopping_cart"][$keys]);
				echo '<script>alert("Item Removed")</script>';
				echo '<script>window.location="cart_shop.php"</script>';
			}
		}
	}
}

?>
<!DOCTYPE html>
<html>
	<head>
		<title>Grocery On-Hand</title>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <style>
                    body {
            background: #eee;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
        
        .clearfix {
            content: "";
            display: table;
            clear: both;
        }
        
        #site-header,
        #site-footer {
            background: #fff;
        }
        
        #site-header {
            margin: 0 0 30px 0;
        }
        
        #site-header h1 {
            font-size: 31px;
            font-weight: 300;
            padding: 40px 0;
            position: relative;
            margin: 0;
        }
        
        a {
            color: #000;
            text-decoration: none;
            -webkit-transition: color .2s linear;
            -moz-transition: color .2s linear;
            -ms-transition: color .2s linear;
            -o-transition: color .2s linear;
            transition: color .2s linear;
        }
        
        a:hover {
            color: black;
        }
        
        #site-header h1 span {
            color: black;
        }
        
        #site-header h1 span.last-span {
            background: #fff;
            padding-right: 150px;
            position: absolute;
            left: 217px;
            -webkit-transition: all .2s linear;
            -moz-transition: all .2s linear;
            -ms-transition: all .2s linear;
            -o-transition: all .2s linear;
            transition: all .2s linear;
        }
        
        #site-header h1:hover span.last-span,
        #site-header h1 span.is-open {
            left: 363px;
        }
        
        #site-header h1 em {
            font-size: 16px;
            font-style: normal;
            vertical-align: middle;
        }
        
        .container {
            font-family: 'Open Sans', sans-serif;
            margin: 0 auto;
            width: 980px;
        }
        
        #cart {
            width: 100%;
        }
        
        #cart h1 {
            font-weight: 300;
        }
        
        #cart a {
            color: black;
            text-decoration: none;
            -webkit-transition: color .2s linear;
            -moz-transition: color .2s linear;
            -ms-transition: color .2s linear;
            -o-transition: color .2s linear;
            transition: color .2s linear;
        }
        
        #cart a:hover {
            color: #000;
        }
        
        .product.removed {
            margin-left: 980px !important;
            opacity: 0;
        }
        
        .product {
            border: 1px solid #eee;
            margin: 20px 0;
            width: 100%;
            height: 195px;
            position: relative;
            -webkit-transition: margin .2s linear, opacity .2s linear;
            -moz-transition: margin .2s linear, opacity .2s linear;
            -ms-transition: margin .2s linear, opacity .2s linear;
            -o-transition: margin .2s linear, opacity .2s linear;
            transition: margin .2s linear, opacity .2s linear;
        }
        
        .product img {
            width: 100%;
            height: 100%;
        }
        
        .product header,
        .product .content {
            background-color: #fff;
            border: 1px solid #ccc;
            border-style: none none solid none;
            float: left;
        }
        
        .product header {
            background: #000;
            margin: 0 1% 20px 0;
            overflow: hidden;
            padding: 0;
            position: relative;
            width: 24%;
            height: 195px;
        }
        
        .product header:hover img {
            opacity: .7;
        }
        
        .product header:hover h3 {
            bottom: 73px;
        }
        
        .product header h3 {
            background: black;
            color: #fff;
            font-size: 22px;
            font-weight: 300;
            line-height: 49px;
            margin: 0;
            padding: 0 30px;
            position: absolute;
            bottom: -50px;
            right: 0;
            left: 0;
            -webkit-transition: bottom .2s linear;
            -moz-transition: bottom .2s linear;
            -ms-transition: bottom .2s linear;
            -o-transition: bottom .2s linear;
            transition: bottom .2s linear;
        }
        
        .remove {
            cursor: pointer;
        }
        
        .product .content {
            box-sizing: border-box;
            -moz-box-sizing: border-box;
            height: 140px;
            padding: 0 20px;
            width: 75%;
        }
        
        .product h1 {
            color: black;
            font-size: 25px;
            font-weight: 300;
            margin: 17px 0 20px 0;
        }
        
        .product footer.content {
            height: 50px;
            margin: 6px 0 0 0;
            padding: 0;
        }
        
        .product footer .price {
            background: #fcfcfc;
            color: #000;
            float: right;
            font-size: 15px;
            font-weight: 300;
            line-height: 49px;
            margin: 0;
            padding: 0 30px;
        }
        
        .product footer .full-price {
            background: black;
            color: #fff;
            float: right;
            font-size: 22px;
            font-weight: 300;
            line-height: 49px;
            margin: 0;
            padding: 0 30px;
            -webkit-transition: margin .15s linear;
            -moz-transition: margin .15s linear;
            -ms-transition: margin .15s linear;
            -o-transition: margin .15s linear;
            transition: margin .15s linear;
        }
        
        .qt,
        .qt-plus,
        .qt-minus {
            display: block;
            float: left;
        }
        
        .qt {
            font-size: 19px;
            line-height: 50px;
            width: 70px;
            text-align: center;
        }
        
        .qt-plus,
        .qt-minus {
            background: #fcfcfc;
            border: none;
            font-size: 30px;
            font-weight: 300;
            height: 100%;
            padding: 0 20px;
            -webkit-transition: background .2s linear;
            -moz-transition: background .2s linear;
            -ms-transition: background .2s linear;
            -o-transition: background .2s linear;
            transition: background .2s linear;
        }
        
        .qt-plus:hover,
        .qt-minus:hover {
            background: black;
            color: #fff;
            cursor: pointer;
        }
        
        .qt-plus {
            line-height: 50px;
        }
        
        .qt-minus {
            line-height: 47px;
        }
        
        #site-footer {
            margin: 30px 0 0 0;
        }
        
        #site-footer {
            padding: 40px;
        }
        
        #site-footer h1 {
            background: #fcfcfc;
            border: 1px solid #ccc;
            border-style: none none solid none;
            font-size: 24px;
            font-weight: 300;
            margin: 0 0 7px 0;
            padding: 14px 40px;
            text-align: center;
        }
        
        #site-footer h2 {
            font-size: 24px;
            font-weight: 300;
            margin: 10px 0 0 0;
        }
        
        #site-footer h3 {
            font-size: 19px;
            font-weight: 300;
            margin: 15px 0;
        }
        
        .left {
            float: left;
        }
        
        .right {
            float: right;
        }
        
        .btn {
            background: black;
            border: 1px solid #999;
            border-style: none none solid none;
            cursor: pointer;
            display: block;
            color: #fff;
            font-size: 20px;
            font-weight: 300;
            padding: 16px 0;
            width: 290px;
            text-align: center;
            -webkit-transition: all .2s linear;
            -moz-transition: all .2s linear;
            -ms-transition: all .2s linear;
            -o-transition: all .2s linear;
            transition: all .2s linear;
        }
        
        .btn:hover {
            color: #fff;
            background: #525252;
        }
        
        .type {
            background: #fcfcfc;
            font-size: 13px;
            padding: 10px 16px;
            left: 100%;
        }
        
        .type,
        .color {
            border: 1px solid #ccc;
            border-style: none none solid none;
            position: absolute;
        }
        
        .color {
            width: 40px;
            height: 40px;
            right: -40px;
        }
        
        .minused {
            margin: 0 50px 0 0 !important;
        }
        
        .added {
            margin: 0 -50px 0 0 !important;
        }
    </style>
	</head>
	<body>
    <header id="site-header">
        <div class="container">
            <a href="../index.html">
                <h1>Grocery On-Hand</h1>
            </a>
        </div>
    </header>
		<div class="container">
			
			<?php
				$query = "SELECT * FROM tbl_product ORDER BY id ASC";
				$result = mysqli_query($connect, $query);
				if(mysqli_num_rows($result) > 0)
				{
					while($row = mysqli_fetch_array($result))
					{
				?>
			<div class="col-md-6">
				<form method="post" action="cart_shop.php?action=add&id=<?php echo $row["id"]; ?>">
					<div style="border:1px solid #333; background-color:#f1f1f1; border-radius:5px; padding:16px;" align="center">
						<img src="../imgs/<?php echo $row["image"]; ?>" class="img-responsive" /><br />

						<h4 class="text-info"><?php echo $row["name"]; ?></h4>

						<h4 class="text-danger">Rs <?php echo $row["price"]; ?></h4>

						<input type="text" name="quantity" value="1" class="form-control" />

						<input type="hidden" name="hidden_name" value="<?php echo $row["name"]; ?>" />

						<input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>" />

						<input type="submit" name="add_to_cart" style="margin-top:5px;" class="btn " value="Add to Cart" />

					</div>
				</form>
			</div>
			<?php
					}
				}
            ?>
           
			<div style="clear:both"></div>
			<br />
			<h3>Order Details</h3>
			<div class="table-responsive">
            <footer id="site-footer">
            <table class="table table-striped table-dark">
            <thead>
					<tr>
						<th width="40%" scope="col">Item Name</th>
						<th width="10%" scope="col">Quantity</th>
						<th width="20%" scope="col">Price</th>
						<th width="15%" scope="col">Total</th>
						<th width="5%" scope="col">Action</th>
                    </tr>
            </thead>
					<?php
					if(!empty($_SESSION["shopping_cart"]))
					{
						$total = 0;
						foreach($_SESSION["shopping_cart"] as $keys => $values)
						{
					?>
					<tr>
						<td><?php echo $values["item_name"]; ?></td>
						<td><?php echo $values["item_quantity"]; ?></td>
						<td>Rs <?php echo $values["item_price"]; ?></td>
						<td>Rs <?php echo number_format($values["item_quantity"] * $values["item_price"], 2);?></td>
						<td><a href="cart_shop.php?action=delete&id=<?php echo $values["item_id"]; ?>"><span class="text-danger"><strong>Remove</strong></span></a></td>
					</tr>
					<?php
							$total = $total + ($values["item_quantity"] * $values["item_price"]);
						}
					?>
					<tr>
                    <td colspan="3" align="right"><h3 class="total"></h3></td>
						<td align="right"><h3 class="total"><strong>Total:Rs<?php echo number_format($total, 2); ?></strong> <h3></td>
                        <td></td>
                   
                    </tr>
					<?php
					}
					?>
						
                </table>
                <div class = "right">
                <a class="btn" href="../html_inter/trackmyorder.html">Checkout</a>
                </div>
            </div>
                
        </div>
        </footer>
	</div>
	<br />
	</body>
</html>

<?php
//If you have use Older PHP Version, Please Uncomment this function for removing error 

/*function array_column($array, $column_name)
{
	$output = array();
	foreach($array as $keys => $values)
	{
		$output[] = $values[$column_name];
	}
	return $output;
}*/
?>