<?php
session_start();
$con =mysqli_connect('localhost','root','');
mysqli_select_db($con,'demo2');
$email = $_POST['email'];
$password = $_POST['password'];
$s ="select * from signin_details where email = '$email' && password='$password'";
$result=mysqli_query($con,$s);
$num=mysqli_num_rows($result);
if($num==1){
    echo '<script>alert("Thanks for login")</script>';
    echo "<meta http-equiv='refresh' content='0; url=../html_inter/vegetables_logout.html' />";
}
else{
    echo '<script>alert("Incorrect Mailid (or) Password ")</script>';
    echo "<meta http-equiv='refresh' content='0; url=../html_inter/forgot_password.html' />";
}

?>

?>