<?php
session_start();
echo '<script>alert("you will getting logout")</script>';
echo "<meta http-equiv='refresh' content='0; url=../index.html' />";

?>