<?php
session_start();
$con =mysqli_connect('localhost','root','');
mysqli_select_db($con,'demo2');
$email = $_POST['email'];
$password = $_POST['password'];
$s = "select * from signin_details where email = '$email'";
$result = mysqli_query($con,$s);
$num = mysqli_num_rows($result);
if($num == 1){
    $ss="update signin_details set password = '$password' where email = '$email' ";
    mysqli_query($con,$ss);
    if($ss){
        echo'<script>alert("thanks for logiin")</script> ';
        echo "<meta http-equiv='refresh' content='0; url=../html_inter/Vegetables.html' />";
       
        

    }
    
    //echo "<meta http-equiv='refresh' content='0; url=.html' />";
}
else{
    echo '<script>alert("Sorry this email donot exist")</script>';
    echo "<meta http-equiv='refresh' content='0; url=../html_inter/signin.html' />";
}