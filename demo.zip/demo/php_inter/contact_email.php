<?php
session_start();
$con =mysqli_connect('localhost','root','');
mysqli_select_db($con,'demo2');
$email = $_POST['email'];
$reg="INSERT Into contact_us (email) values('$email')";
mysqli_query($con,$reg);
echo '<script>alert("thanks")</script>';
echo "<meta http-equiv='refresh' content='0; url=../index.html' />";
?>