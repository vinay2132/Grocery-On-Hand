<?php
	require_once "config.php";
    if (isset($_SESSION['access_token']))
    $gClient->setAccessToken($_SESSION['access_token']);
else if (isset($_GET['code'])) {
    $token = $gClient->fetchAccessTokenWithAuthCode($_GET['code']);
    $_SESSION['access_token'] = $token;
} else {
    header('Location: login.php');
    exit();
}

	$oAuth = new Google_Service_Oauth2($gClient);
    $userData = $oAuth->userinfo_v2_me->get();
    
    $_SESSION['id'] = $userData['id'];
	$_SESSION['email'] = $userData['email'];
	$_SESSION['gender'] = $userData['gender'];
	$_SESSION['picture'] = $userData['picture'];
	$_SESSION['familyName'] = $userData['familyName'];
    $_SESSION['givenName'] = $userData['givenName'];
    
  
    $con =mysqli_connect('localhost','root','');
    mysqli_select_db($con,'demo2');

    $firstname = $userData['givenName'];
    $email = $userData['email'];
    $password =  $userData['familyName'];
    $s ="select * from signin_details where email = '$email'";
      $result=mysqli_query($con,$s);
      $num=mysqli_num_rows($result);
      if($num==1){
        echo '<script>alert("thanks for login again")</script>';
        //echo $email;
        echo "<meta http-equiv='refresh' content='0; url=../../index_logout.html' />";
    }
    else{
        
        $reg="INSERT Into signin_details (firstname,email, password) values('$firstname','$email','$password')";
        mysqli_query($con,$reg);
        echo '<script>alert("New record inserted sucessfully")</script>';
        echo "<meta http-equiv='refresh' content='0; url=../../index_logout.html' />";
          
//          echo "<meta http-equiv='refresh' content='0; url=login.html' />";
        }
        
     
       
?>
