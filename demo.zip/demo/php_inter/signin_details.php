<?php
session_start();
$con =mysqli_connect('localhost','root','');
mysqli_select_db($con,'demo2');
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$email = $_POST['email'];
$countryCode = $_POST['countryCode'];
$phone = $_POST['phone'];
$jobtitle = $_POST['jobtitle'];
$password = $_POST['password'];
$passwordConfirmation = $_POST['passwordConfirmation'];
$s ="select * from signin_details where email = '$email'";
$result=mysqli_query($con,$s);
$num=mysqli_num_rows($result);
if($password == $passwordConfirmation){
    if($num==1){
        echo '<script>alert("Someone already register using this email")</script>';
        echo "<meta http-equiv='refresh' content='0; url=../html_inter/contact_us.html' />";
      }
      else{
        $reg="INSERT Into signin_details (firstname, lastname, email, countryCode, phone, jobtitle, password) values('$firstname','$lastname','$email','$countryCode','$phone' ,'$jobtitle' ,'$password')";
        mysqli_query($con,$reg);
        echo '<script>alert("New record inserted sucessfully")</script>';
        echo "<meta http-equiv='refresh' content='0; url=../html_inter/vegetables_logout.html' />";
      }
}
else{
    echo'<script>alert("pasword and passwordConfirmation where not same. Please try again!")</script>';
    echo "<meta http-equiv='refresh' content='0; url=../index.html' />";
  
}
session_destroy();
?>